package com.example.student_shared_preference

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
