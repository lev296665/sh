import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => MyAppState();
}

class MyAppState extends State<MyApp> {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();

  String gender = "Male";
  String course = "BCA";
  String result = "";

  // Save data
  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString("FirstName", firstNameController.text);
    await prefs.setString("LastName", lastNameController.text);
    await prefs.setString("Age", ageController.text);
    await prefs.setString("Gender", gender);
    await prefs.setString("Course", course);

    setState(() {
      result = "✅ Data Saved Successfully!";
    });
  }

  // Load data
  Future<void> loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? fname = prefs.getString("FirstName");
    String? lname = prefs.getString("LastName");
    String? age = prefs.getString("Age");
    String? gen = prefs.getString("Gender");
    String? cor = prefs.getString("Course");

    setState(() {
      result = "First Name: ${fname ?? ''}\n"
          "Last Name: ${lname ?? ''}\n"
          "Age: ${age ?? ''}\n"
          "Gender: ${gen ?? ''}\n"
          "Course: ${cor ?? ''}";
    });
  }

  @override
  Widget build(BuildContext context) {
    List<DropdownMenuItem<String>> courseItems = const [
      DropdownMenuItem(value: 'BCA', child: Text('BCA')),
      DropdownMenuItem(value: 'MCA', child: Text('MCA')),
      DropdownMenuItem(value: 'MSE_IT', child: Text('MSE_IT')),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Shared Preferences Example")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(labelText: "Enter First Name"),
              ),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(labelText: "Enter Last Name"),
              ),
              TextField(
                controller: ageController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Enter Age"),
              ),
              const SizedBox(height: 20),
              const Text("Select Gender:"),
              RadioListTile<String>(
                title: const Text("Male"),
                value: "Male",
                groupValue: gender,
                onChanged: (value) => setState(() => gender = value!),
              ),
              RadioListTile<String>(
                title: const Text("Female"),
                value: "Female",
                groupValue: gender,
                onChanged: (value) => setState(() => gender = value!),
              ),
              RadioListTile<String>(
                title: const Text("Other"),
                value: "Other",
                groupValue: gender,
                onChanged: (value) => setState(() => gender = value!),
              ),
              const SizedBox(height: 20),
              const Text("Select Course:"),
              DropdownButton<String>(
                value: course,
                items: courseItems,
                onChanged: (String? newValue) {
                  setState(() {
                    if (newValue != null) {
                      course = newValue;
                    }
                  });
                },
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(onPressed: saveData, child: const Text("Save")),
                  ElevatedButton(onPressed: loadData, child: const Text("Load")),
                ],
              ),
              const SizedBox(height: 20),
              Text(result,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}
