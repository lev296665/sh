import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'student_list_screen.dart';

class StudentFormScreen extends StatefulWidget {
  const StudentFormScreen({super.key});

  @override
  State<StudentFormScreen> createState() => _StudentFormScreenState();
}

class _StudentFormScreenState extends State<StudentFormScreen> {
  final _nameController = TextEditingController();
  final _rollController = TextEditingController();
  final _courseController = TextEditingController();
  final DatabaseHelper dbHelper = DatabaseHelper();

  Future<void> _saveStudent() async {
    if (_nameController.text.isEmpty ||
        _rollController.text.isEmpty ||
        _courseController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    await dbHelper.insertStudent({
      "name": _nameController.text.trim(),
      "rollNumber": _rollController.text.trim(),
      "course": _courseController.text.trim(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Student added successfully")),
    );

    _nameController.clear();
    _rollController.clear();
    _courseController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Student")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: _rollController,
              decoration: const InputDecoration(labelText: "Roll Number"),
            ),
            TextField(
              controller: _courseController,
              decoration: const InputDecoration(labelText: "Course"),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _saveStudent,
              icon: const Icon(Icons.save),
              label: const Text("Save"),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const StudentListScreen()),
                );
              },
              icon: const Icon(Icons.list),
              label: const Text("View Students"),
            ),
          ],
        ),
      ),
    );
  }
}
