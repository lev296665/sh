import 'package:flutter/material.dart';
import 'database_helper.dart';

class StudentEditScreen extends StatefulWidget {
  final Map<String, dynamic> student;
  const StudentEditScreen({super.key, required this.student});

  @override
  State<StudentEditScreen> createState() => _StudentEditScreenState();
}

class _StudentEditScreenState extends State<StudentEditScreen> {
  late TextEditingController nameController;
  late TextEditingController rollController;
  late TextEditingController courseController;
  final DatabaseHelper dbHelper = DatabaseHelper();

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.student["name"]);
    rollController = TextEditingController(text: widget.student["rollNumber"]);
    courseController = TextEditingController(text: widget.student["course"]);
  }

  Future<void> _updateStudent() async {
    await dbHelper.updateStudent(widget.student["id"], {
      "name": nameController.text,
      "rollNumber": rollController.text,
      "course": courseController.text,
    });
    Navigator.pop(context);
  }

  @override
  void dispose() {
    nameController.dispose();
    rollController.dispose();
    courseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Student")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: "Name")),
            TextField(controller: rollController, decoration: const InputDecoration(labelText: "Roll Number")),
            TextField(controller: courseController, decoration: const InputDecoration(labelText: "Course")),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _updateStudent,
              icon: const Icon(Icons.save),
              label: const Text("Update"),
            ),
          ],
        ),
      ),
    );
  }
}
